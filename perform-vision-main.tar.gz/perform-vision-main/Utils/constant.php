<?php

define("NB_RESULTATS_PAR_PAGE", 25);

const APP_URL = 'http://localhost/MVC';
const SENDER_EMAIL_ADDRESS = 'once.sae@email.com';