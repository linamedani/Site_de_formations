<!--Fotter-->

<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="UTF-8" />
		
		<link rel="stylesheet" href="../Content/css/end_footer.css" />
		
		</head>
	<body>


<footer>
<ul>
	<li>
		<div class="container">
        <p >Contactez-nous</p>
        <p>Mentions légales</p>
        <p>Centre d’aide</p>
	</div>
	</li>
	<li>
    <div class="container2">
        <p>Politique de Confidentialité</p>
        <p>Conditions d’utilisation</p>
        <p>FAQ</p>
	</div>
	</li>
	<li>
    <div class="container3">
        <p>Cours en ligne</p>
        <p>Formateurs</p>
        <p>Activités</p>
	</div>
	</li>
<li>
		<div class="social-icons">
			<img src="../Content/images/instagramme.png"  alt="Instagram">
			<img src="../Content/images/facebook.png"  alt="facebook">
</div>
</li>
</ul>
<br>
<p> &copy; 2023 Mon Site Web. Tous droits réservés.   ONCE    .</p>

	</footer>
</body>
</html>